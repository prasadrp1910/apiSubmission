package com.cts.api.controller;

import java.util.Date;

import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.xml.sax.SAXException;

import com.cts.bo.Employee;
import com.cts.bo.ErrorLog;
import com.cts.main.dao.EmployeeDao;
import com.cts.main.dao.ErrorLoggerDao;
import com.cts.util.ValidatorUtil;

@RestController
public class EmployeeController {
	
	Logger logger = Logger.getLogger(EmployeeController.class);

	@Autowired
	EmployeeDao empDao;
	
	@Autowired
	ErrorLoggerDao erroLoggerDao;
	
	//to enable logging in same class methods
	@Autowired
	EmployeeController controller;
	
		
    @PostMapping(path = "/saveUpdateEmpData", consumes=MediaType.APPLICATION_XML_VALUE)
    
    public ResponseEntity<String> customerInformation(@RequestBody Employee emp) {
    	
    	logger.info("Request received in controller");
    	
    	//pojo to log error log
    	ErrorLog errorLog = new ErrorLog();
    	
    	//Validate input xml against XSD
    	   if(!controller.ValidateInputData(emp)) {
    		   return ResponseEntity.ok()
       		        .header("REQ_INVALID", "failed")
       		        .body("\"Customer information received in invalid format");
    	   }
    	   
    	//Verify if employee is already in System
    	java.sql.Date empRecordDate = controller.verifyEmployeeRecord(emp);
    	
    	if(empRecordDate==null) {  //Save employee if record is new
    		controller.saveEmployeeData(emp);
    		return ResponseEntity.ok()
    		        .header("EMP_SAVE", "success")
    		        .body("\"Customer information Saved successfully for ID " + emp.getId()+ " Name "+emp.getName());
    	 
    	}else {
    		//Update record when employee is already in system
    		
    		if(controller.updateEmployeeData(emp, empRecordDate)) {
    		return ResponseEntity.ok()
    		        .header("EMP_UPDATE", "success")
    		        .body("\"Customer information updated successfully for ID" + emp.getId()+" Name "+emp.getName());
    		}else {
    			//update attempted within 24 hours of record creation
    			errorLog.setErrorCode(300);
        		errorLog.setErrorType("Record Update time");
        		errorLog.setErrorDesc("Record for employee "+emp.getId() +"created less than 24  hours before. Update failed.");
        		errorLog.setErrorCreated(new java.sql.Date(new Date().getTime()));
        		erroLoggerDao.logError(errorLog);
        		return ResponseEntity.ok()
        		        .header("EMP_UPDATE", "failed")
        		        .body("\"Customer information update failed as record can not be updated within 24 hours of creation for ID" + emp.getId()+" Name "+emp.getName());
        	
    		}
    	}
    		
    	}
    	
    	
    /**
     * Validate input against xsd
     * @param emp
     * @return
     */
    public boolean ValidateInputData(Employee emp) {
    	ErrorLog errorLog = new ErrorLog();
    	try {
        	ValidatorUtil.validateRequest(emp);
        	
        	}catch (JAXBException |SAXException e) {
        		//Log validation Errors
        		errorLog.setErrorCode(100);
        		errorLog.setErrorType("Validation");
        		errorLog.setErrorDesc("Invalid request format");
        		errorLog.setErrorCreated(new java.sql.Date(new Date().getTime()));
        		erroLoggerDao.logError(errorLog);
        		e.printStackTrace();
        		return false;
    		}catch (Exception e) {
    			logger.info("Generic Exception");
    			errorLog.setErrorCode(200);
        		errorLog.setErrorType("Generic Exception");
        		errorLog.setErrorDesc("Gneric Exception "+e.getMessage());
        		errorLog.setErrorCreated(new java.sql.Date(new Date().getTime()));
        		erroLoggerDao.logError(errorLog);    		
    			return false;
    		}
    	return true;

    }
    /**
     * verify if employee records exists in DB and return created time if exists
     * @param emp
     * @return
     */
    public java.sql.Date verifyEmployeeRecord(Employee emp) {
    	java.sql.Date empRecordDate = empDao.findEmployeeById(emp.getId());
    	return empRecordDate;
    }
    
    /**
     * Save valid employee in DB
     * @param emp
     */
    public void saveEmployeeData(Employee emp) {
    	empDao.save(emp);
    }
    
    /**
     * update employee data in DB, verify if update is attempted within 24 hours of record creation
     * @param emp
     * @param empRecordDate
     * @return
     */
    public boolean updateEmployeeData(Employee emp,java.sql.Date empRecordDate) {
    	boolean isUpdateSuccss = false;
    	if(ValidatorUtil.isUpdateValid(empRecordDate)) {
    		empDao.update(emp);
    		isUpdateSuccss = true;
    	
    }else {
    	return false;
    }
    	return isUpdateSuccss;
}
    }
