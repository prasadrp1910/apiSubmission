package com.cts.main.dao;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bo.ErrorLog;

@Repository
@Transactional
public class ErrorLoggerDao {
	
	Logger log = Logger.getLogger(ErrorLoggerDao.class);

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	final String INSERT_SQL = "insert into ERROR_LOG (errorCode, errorType, errorDesc,errorCreated) values (?, ?, ?, ?)";
	/**
	 * Log error message in DB
	 * @param errorLog
	 */
	public void logError(ErrorLog errorLog) {
		log.info("Logging error for errorCode"+errorLog.getErrorCode() + "at "+errorLog.getErrorCreated());
		jdbcTemplate.update(INSERT_SQL,errorLog.getErrorCode(),errorLog.getErrorType(),errorLog.getErrorDesc(),errorLog.getErrorCreated());
		 
	}
}
