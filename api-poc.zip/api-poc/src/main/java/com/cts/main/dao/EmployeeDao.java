package com.cts.main.dao;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bo.Employee;

@Repository
@Transactional
public class EmployeeDao {
	
	Logger log = Logger.getLogger(EmployeeDao.class);
	
	final String INSERT_SQL = "insert into EMPLOYEE (id, name, department,created_ts,updated_ts) values (?, ?, ?, ?, ?)";
	final String UPDATE_SQL = "update EMPLOYEE set name = ? , department= ? ,updated_ts=? where id = ?";
	final String SELECT_SQL = "SELECT created_ts FROM EMPLOYEE WHERE ID = ?";
	java.sql.Date created_ts = new java.sql.Date(Calendar.getInstance().getTime().getTime());
	java.sql.Date updated_ts = new java.sql.Date(Calendar.getInstance().getTime().getTime());
	
	
	@Autowired
	  private JdbcTemplate jdbcTemplate;
	  /**
	   * Save employee object in DB
	   * @param employee
	   */
	  public void save(Employee employee) {
		  log.info("Saving Employee Details");
		  
	     jdbcTemplate.update(INSERT_SQL, employee.getId(),employee.getName(),employee.getDepartment(),created_ts,updated_ts);
	  }
	  /**
	   * Update employee record in DB
	   * @param employee
	   */
	  public void update(Employee employee) {		  
	 	 log.info("Updating Employee Details");
	      jdbcTemplate.update(UPDATE_SQL, employee.getName(),employee.getDepartment(),updated_ts,employee.getId());
	  }
 /**
  * Verify if employee record exists in DB, return employee created time if record available
  * @param id
  * @return
  */
 @SuppressWarnings("unchecked")
 public Date findEmployeeById(int id) {
	 
		 	 
	List<Date> dateLst  = jdbcTemplate.query(SELECT_SQL,new RowMapper() {
		public Object mapRow(ResultSet rs, int arg1) throws SQLException {
			 return rs.getDate(1);
	}},id);
	if ( dateLst.isEmpty() ){
		  return null;
		}else if ( dateLst.size() == 1 ) {
		  return dateLst.get(0);
		}
		return null;     
 }
	  
	  

}
