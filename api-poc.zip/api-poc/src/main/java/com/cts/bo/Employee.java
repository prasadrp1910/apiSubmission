package com.cts.bo;

import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlRootElement(name="Employee")
@XmlAccessorType(XmlAccessType.FIELD)
public class Employee {
	
	private int id;
	private String name;
	private String department;
	private Date created_ts;
	private Date updated_ts;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	
	public void setDepartment(String department) {
		this.department = department;
	}
	
	public Date getCreated_ts() {
		return created_ts;
	}
	
	public void setCreated_ts(Date created_ts) {
		this.created_ts = created_ts;
	}
	
	public Date getUpdated_ts() {
		return updated_ts;
	}
	
	public void setUpdated_ts(Date updated_ts) {
		this.updated_ts = updated_ts;
	}
	
}

 


