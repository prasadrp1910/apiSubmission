package com.cts.util;

import java.io.File;
import java.sql.Date;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.apache.log4j.Logger;
import org.springframework.util.ResourceUtils;
import org.xml.sax.SAXException;

import com.cts.bo.Employee;

public class ValidatorUtil {

	static Logger log = Logger.getLogger(ValidatorUtil.class);
	/**
	 * Validate incoming request object against xml schema
	 * @param e
	 * @throws JAXBException
	 * @throws SAXException
	 * @throws Exception
	 */
	public static void validateRequest(Employee e) throws JAXBException,SAXException , Exception {
	
		log.info("Entering validateRequest to Validate request" );
		//Validate against xsd
		JAXBContext context ;
	    	   
		context = JAXBContext.newInstance(Employee.class);
		Marshaller jaxbMarshaller = context.createMarshaller();
		 
        jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        File xmlFile = new File("employee.xml");        
        File xsdFile = ResourceUtils.getFile("classpath:Employee.xsd");         
        jaxbMarshaller.marshal(e, xmlFile);		
		Unmarshaller jaxbUnmarshaller = context.createUnmarshaller();		
		SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		Schema employeeSchema = sf.newSchema(xsdFile);
		jaxbUnmarshaller.setSchema(employeeSchema);	
		Employee employee = (Employee) jaxbUnmarshaller.unmarshal(xmlFile);
	
	}
	/**
	 * Verify if update employee is done within 24 hours
	 * @param empRecordDate
	 * @return
	 */
	public static boolean isUpdateValid(Date empRecordDate) {
		long MILLIS_PER_DAY = 24 * 60 * 60 * 1000L;
		Date now  = new java.sql.Date(new java.util.Date().getTime()); 
	    boolean moreThanDay = Math.abs(now.getTime()-empRecordDate.getTime()) > MILLIS_PER_DAY;
	    return moreThanDay;
	}
}
