package com.cts.aspect;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
/**
 * This class is logging method entry and exit of all methods within controller class
 * @author PRASADPATANKAR
 *
 */
public class EmployeeServiceAspect {

	Logger log = Logger.getLogger(EmployeeServiceAspect.class);
	long startTime=0;
	@Before(value = "execution(* com.cts.api.controller.EmployeeController.*(..))")
	public void beforeAdvice(JoinPoint joinPoint) {
		
		this.startTime = System.currentTimeMillis();
		
		log.info("Entering Method "+joinPoint.getSignature());
	}

	@After(value = "execution(* com.cts.api.controller.EmployeeController.*(..))")
	public void afterAdvice(JoinPoint joinPoint) {
		
		log.info("After method:" + joinPoint.getSignature() + "total Execution time "+(System.currentTimeMillis()-this.startTime));

		
	}
}

