CREATE TABLE IF NOT EXISTS EMPLOYEE 
(
id int, 
name varchar,
department varchar,
created_ts Date,
updated_ts Date
);

CREATE TABLE IF NOT EXISTS ERROR_LOG (
errorCode int, 
errorType varchar(50),
errorDesc varchar(200),
errorCreated Date
);