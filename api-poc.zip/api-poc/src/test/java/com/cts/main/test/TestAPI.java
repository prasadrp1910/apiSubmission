package com.cts.main.test;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class TestAPI {

	/**
	 * Test Class to verify individual requests
	 * @param args
	 */
	public static void main(String[] args) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_XML);
		
		RestTemplate restTemplate = new RestTemplate();
		
		String inputSave = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + 
				"<Employee>\r\n" + 
				"    <id>500</id>\r\n" + 
				"    <name>Prasad R Patankar</name>\r\n" +
				"    <department>IT</department>\r\n" + 
				"</Employee>";
		/*
		String inputUpdate = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + 
				"<Employee>\r\n" + 
				"    <id>10001</id>\r\n" + 
				"    <name>Prasad</name>\r\n" +
				"    <department>OPERATIONS</department>\r\n" + 
				"</Employee>";
		String inputInvalid = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + 
				"<Employee>\r\n" + 
				"    <id>30001</id>\r\n" + 
				"    <name>Prasad</name>\r\n" +
				"    <department>INFRA</department>\r\n" + 
				"</Employee>";
		
		*/		
		HttpEntity<String> request = new HttpEntity<String>(inputSave, headers);
		ResponseEntity<String> response = restTemplate.postForEntity("http://localhost:8080/EmployeeLoader/saveUpdateEmpData", request, String.class);
		
		System.out.println(response.getHeaders() + response.getBody());

	}

}
