package com.cts.main.test;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

/**
 * This Class is making call to API , In a case when resource is not available it will make 3 times with a gap of 10 seconds 
 * each if the restful service is unavailable temporarily.
 * @author PRASADPATANKAR
 *
 */
public class TestAPIRettry {
	
	final static String apiURL = "http://localhost:8081/EmployeeLoader/saveUpdateEmpData";

	public static void main(String[] args)  {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_XML);
		HttpEntity<String> request = new HttpEntity<String>("", headers);
		boolean dowait = false;
		for(int i=0;i<3;i++) {
			try {
			if(dowait) {
				System.out.println("Waiting for 10 seconds before making another call");
				Thread.sleep(10000);
			}
			
		ResponseEntity<String> response = restTemplate.postForEntity(apiURL, request, String.class);
			}catch (ResourceAccessException e) {
				System.out.println("Resource Not available "+e.getMessage());
				dowait = true;
			}catch (Exception e) {
				dowait = false;
			}
		}

	}

}
