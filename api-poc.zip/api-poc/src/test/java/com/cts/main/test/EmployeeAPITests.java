package com.cts.main.test;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
 

 
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class EmployeeAPITests {

	@Autowired
    private TestRestTemplate restTemplate;
     
    @Test
    public void testAddEmployeeSuccess() throws URISyntaxException
    {
        final String baseUrl = "http://localhost:8080/EmployeeLoader/saveUpdateEmpData";
        URI uri = new URI(baseUrl);
        String inputSave = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + 
				"<Employee>\r\n" + 
				"    <id>801</id>\r\n" + 
				"    <name>Prasad</name>\r\n" +
				"    <department>IT</department>\r\n" + 
				"</Employee>";
         
        HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_XML);
        
		HttpEntity<String> request = new HttpEntity<String>(inputSave, headers);
         
        ResponseEntity<String> result = this.restTemplate.postForEntity(uri, request, String.class);
         
        //Verify request succeed
        Assert.assertTrue(result.getHeaders().get("EMP_SAVE")!=null);
    }
    
    @Test
    public void testUpdateEmployeeSuccess() throws URISyntaxException
    {
        final String baseUrl = "http://localhost:8080/EmployeeLoader/saveUpdateEmpData";
        URI uri = new URI(baseUrl);
        String inputSave = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + 
				"<Employee>\r\n" + 
				"    <id>801</id>\r\n" + 
				"    <name>Prasad</name>\r\n" +
				"    <department>OPERATIONS</department>\r\n" + 
				"</Employee>";
         
        HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_XML);
        
		HttpEntity<String> request = new HttpEntity<String>(inputSave, headers);
         
        ResponseEntity<String> result = this.restTemplate.postForEntity(uri, request, String.class);
         
        //Verify request succeed
        Assert.assertTrue(result.getHeaders().get("EMP_UPDATE")!=null);
    }
    
    @Test
    public void testInvalidEmployeeFail() throws URISyntaxException
    {
        final String baseUrl = "http://localhost:8080/EmployeeLoader/saveUpdateEmpData";
        URI uri = new URI(baseUrl);
        String inputSave = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + 
				"<Employee>\r\n" + 
				"    <id>801</id>\r\n" + 
				"    <name>Prasad</name>\r\n" +
				"    <department>INFRA</department>\r\n" + 
				"</Employee>";
         
        HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_XML);
        
		HttpEntity<String> request = new HttpEntity<String>(inputSave, headers);
         
        ResponseEntity<String> result = this.restTemplate.postForEntity(uri, request, String.class);
         
        //Verify request succeed
        Assert.assertTrue(result.getHeaders().get("REQ_INVALID")!=null);
    }
    
}
